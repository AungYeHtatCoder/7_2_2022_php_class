<?php 
namespace Libs\Databases;
use PDO;
use PDOException;

class TrInfoTable 
{
 private $db = null;

 public function __construct($db)
 {
  $this->db = $db->connect();
 }

 // get all data with join program, class, subject, user
 public function GetTrInfoAllData()
 {
  $statement = $this->db->prepare("
            SELECT tr_infos.*, programs.program_name, classes.class_name, subjects.subject_name, users.name, users.email
            FROM tr_infos 
            LEFT JOIN programs ON tr_infos.program_id = programs.id
            LEFT JOIN classes ON tr_infos.class_id = classes.id
            LEFT JOIN subjects ON tr_infos.subject_id = subjects.id
            LEFT JOIN users ON tr_infos.user_id = users.id
        ");
  $statement->execute();
  $row = $statement->fetchAll();
  return $row;
  
 }

}