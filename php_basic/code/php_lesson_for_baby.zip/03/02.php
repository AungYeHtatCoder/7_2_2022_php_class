<?php
/* This is a section
   of multi-line comments
   which will not be
   interpreted */
?>
