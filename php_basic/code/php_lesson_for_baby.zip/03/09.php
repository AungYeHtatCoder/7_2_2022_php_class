<?php
  $author = "Scott Adams";

  $out = <<<_END
  Normal people believe that if it ain’t broke, don’t fix it.
  Engineers believe that if it ain’t broke, it doesn’t have enough
  features yet.

  - $author.
_END;
?>