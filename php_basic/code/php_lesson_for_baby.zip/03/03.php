<?php
  $mycounter = 1;
  $mystring  = "Hello";
  $myarray   = array("One", "Two", "Three");

  echo "The value of \$mycounter is " . $mycounter . "<br>";
  echo "The value of \$mystring is " . $mystring . "<br>";
  echo "The value of \$myarray is " . $myarray[2] . "<br>";
  echo $myarray[0];
  echo "<br>";
  echo $myarray[1];
  echo "<br>";

  echo $myarray[2];
?>