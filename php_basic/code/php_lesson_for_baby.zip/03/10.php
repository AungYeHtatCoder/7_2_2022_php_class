<?php
  $number = 12345 * 67890;
  echo substr($number, 3, 1);
?>
