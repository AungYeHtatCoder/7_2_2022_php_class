<?php 
$link = mysqli_connect("localhost", "root", "", "one_project_db");