<?php include("layout/head.php") ?>

<body id="home" style="background-color: rgb(78, 44, 21)">
 <!-- nav start -->
 <?php include("layout/navbar.php"); ?>
 <?php include("layout/nav_side.php"); ?>
 <!-- nav end -->

 <!-- section start -->
 <?php include("layout/section_one.php"); ?>

 <!-- section end -->
 <!-- about start -->
 <?php include("layout/about_section.php") ?>

 <!-- about end -->

 <!-- customer start -->
 <div class="container" id="blogs">
  <h1 class="text-center mt-4 text-light fw-bold">
   COMMON CUSTOMER'S QUESTIONS
  </h1>
  <?php include("layout/customer_section.php") ?>
  <!-- customer end -->

  <!-- Contact start -->
  <?php include("layout/contact_section.php") ?>
  <!-- Contact end -->
 </div>
 <!-- footer start -->
 <?php include("layout/footer.php"); ?>