<div class="row py-5" style="background-color: rgb(78, 44, 21)">
 <div class="col-lg-6 mt-5">
  <p class="text-uppercase text-light display-2 fw-bolder mt-5">
   <span class="px-5">coffee</span>
  </p>
  <p class="text-uppercase text-white h5 px-5 mb-1 lead mx-5">
   -service for office
  </p>
  <p class="text-uppercase text-white h5 px-5 mb-1 lead mx-5">
   -breakrooms and
  </p>
  <p class="text-uppercase text-white h5 px-5 mb-1 lead mx-5">
   -free delivery
  </p>
  <div class="btn-light mt-4 px-5 mx-5">
   <a href="https://www.ncausa.org/About-Coffee" class="btn active text-light" style="background-color: rgb(97, 76, 76)"
    role="button">LEARN MORE</a>
  </div>
 </div>
 <div class="col-lg-6">
  <img src="img/222 (2).png" alt="" class="img-fluid w-75" />
 </div>
</div>