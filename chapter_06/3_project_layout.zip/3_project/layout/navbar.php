   <nav class="navbar navbar-expand-lg opacity-75 py-3 shadow fixed-top" style="background-color: rgb(78, 44, 21)"
    id="mainNav">
    <div class="container px-4 px-lg-5">
     <div class="waviy">
      <span><img src="img/222 (3).png" class="w-25" alt="" style="height: 4rem" /></span>
      <span style="--i: 2" class="text-white">D</span>
      <span style="--i: 3" class="text-white">E</span>
      <span style="--i: 4" class="text-white">N</span>
      <span style="--i: 4" class="text-white">N</span>
      <span style="--i: 5" class="text-white">Y</span>
      <span style="--i: 6" class="text-white"></span>
      <span style="--i: 7" class="text-white">C</span>
      <span style="--i: 8" class="text-white">O</span>
      <span style="--i: 4" class="text-white">F</span>
      <span style="--i: 8" class="text-white">F</span>
      <span style="--i: 8" class="text-white">E</span>
      <span style="--i: 8" class="text-white">E</span>
     </div>

     <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
      aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
     </button>

     <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
       <li class="nav-item fw-bold px-4 col-md">
        <a class="nav-link active text-light border border-light" aria-current="page" href="#home">Home</a>
       </li>

       <li class="nav-item fw-bold px-4">
        <a class="nav-link text-light border border-light" href="#ourServices">Our Services</a>
       </li>
       <li class="nav-item fw-bold px-4">
        <a class="nav-link text-light border border-light" href="#aboutus">About Us</a>
       </li>
       <li class="nav-item fw-bold px-4">
        <a class="nav-link text-light border border-light" href="#contactUs">Contact Us</a>
       </li>
       <li class="nav-item fw-bold px-4">
        <a class="nav-link text-light border border-light" href="#blogs">Blogs</a>
       </li>
       <li class="nav-item fw-bold px-4 float-end">
        <a class="nav-link text-light border border-light" href="#agent">Agent</a>
       </li>
       <li class="nav-item fw-bold px-4 float-end">
        <a class="nav-link text-light border border-light" href="#api">API</a>
       </li>
      </ul>
     </div>
    </div>
   </nav>