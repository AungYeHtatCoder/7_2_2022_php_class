<div class="accordion mt-3" id="myAccordion">
 <div class="accordion-item mb-3">
  <h2 class="accordion-header" id="headingOne">
   <button type="button" class="accordion-button collapsed text text-light" style="background: rgb(138, 97, 68)"
    data-bs-toggle="collapse" data-bs-target="#collapseOne">
    How do I get a dozen cup of coffee for a picnic in Lagos?
   </button>
  </h2>
  <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
   <div class="card-body">
    <p class="text">
     Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore
     corporis quae dignissimos error reiciendis molestiae sit
     voluptatum dolor excepturi! Aspernatur fugiat magni officiis
     facilis obcaecati excepturi nulla quas tempore nostrum!
    </p>
   </div>
  </div>
 </div>
 <div class="accordion-item mb-3 bgcolor">
  <h2 class="accordion-header" id="headingTwo">
   <button type="button" class="accordion-button text-white" data-bs-toggle="collapse" data-bs-target="#collapseTwo"
    style="background: rgb(138, 97, 68)">
    I'm in Enugu, How do I reach You?
   </button>
  </h2>
  <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
   <div class="card-body">
    <p>
     Lorem ipsum, dolor sit amet consectetur adipisicing elit.
     Nostrum, sint similique perspiciatis velit minima nisi
     repudiandae fuga excepturi cum architecto atque expedita qui
     iure deserunt nobis soluta impedit! Laborum, et?
    </p>
   </div>
  </div>
 </div>
 <div class="accordion-item mb-3 bgcolor">
  <h2 class="accordion-header" id="headingThree">
   <button type="button" class="accordion-button collapsed text-white" data-bs-toggle="collapse"
    data-bs-target="#collapseThree" style="background: rgb(138, 97, 68)">
    Whithin Nsukka? Find your question below
   </button>
  </h2>
  <div id="collapseThree" class="accordion-collapse collapse show" data-bs-parent="#myAccordion">
   <div class="card-body">
    <p>Is There any benefit of buying from your agents?</p>
    <p>
     I want to purchase coffee at intervals in the work Possible?
    </p>
    <p>Is there any benefit of buying from your agents?</p>
    <p>Is There any benefit of buying from your agents?</p>
    <p>Is There any benefit of buying from your agents?</p>
    <p>Is there any benefit of buying now?</p>
    <p>
     I want to purchase coffee at intervals in the work Possible?
    </p>
   </div>
  </div>
 </div>

 <div class="accordion-item mb-3">
  <h2 class="accordion-header" id="headingFour">
   <button type="button" class="accordion-button collapsed text-white" data-bs-toggle="collapse"
    data-bs-target="#collapseFour" style="background: rgb(138, 97, 68)">
    I'm in Ebony State, How do I reach You?
   </button>
  </h2>
  <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
   <div class="card-body">
    <p>Is There any benefit of buying from your agents?</p>
   </div>
  </div>
 </div>

 <div class="accordion-item mb-3 bgcolor">
  <h2 class="accordion-header" id="headingFive">
   <button type="button" class="accordion-button collapsed text-white" data-bs-toggle="collapse"
    data-bs-target="#collapseFive" style="background: rgb(138, 97, 68)">
    I'm in Edo State, How do I reach You?
   </button>
  </h2>
  <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#myAccordion">
   <div class="card-body">
    <p>Is There any benefit of buying from your agents?</p>
   </div>
  </div>
 </div>
</div>