<section id="ourServices">
 <div class="container-fluid" style="background-color: rgb(78, 44, 21)">
  <h1 class="text-center fw-bold display- text-light mb-3">
   OUR SERVICES
  </h1>
  <div class="row">
   <div class="owl-carousel owl-theme">
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (1).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (2).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (3).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (4).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (5).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (6).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (7).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
    <div class="item mb-4">
     <div class="card border-0 shadow">
      <img src="img/1 (8).jpg" alt="image" class="card-img-top" />
      <div class="card-body" style="background-color: rgb(78, 44, 21)">
       <h4 class="text-center text-light">Outdoor Coffee</h4>
      </div>
      <div class="dropdown text-center" style="background-color: rgb(78, 44, 21)">
       <button class="dropdown-toggle text-light" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
        aria-expanded="false" style="background-color: rgb(78, 44, 21)"></button>
       <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="#">Action</a></li>
        <li>
         <a class="dropdown-item" href="#">Another action</a>
        </li>
        <li>
         <a class="dropdown-item" href="#">Something else here</a>
        </li>
       </ul>
      </div>
     </div>
    </div>
    <!-- item end -->
   </div>
  </div>
 </div>
</section>