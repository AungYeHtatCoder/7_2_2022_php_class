<footer class="footer-area section-gap">
 <div class="container my-5">
  <div class="row">
   <div class="col-lg-5 col-sm-6">
    <div class="single-footer-widget">
     <h6 class="text-white">About Us</h6>
     <p class="text-white">
      Welcome to Lorem ipsum dolor sit amet consectetur adipisicing
      elit. Expedita blanditiis aperiam ducimus iste ipsum minus
      mollitia. Tempora provident ea similique adipisci, voluptatem
      illo dicta eum repellat quos deleniti! Minus, deserunt!
     </p>
     <p class="footer-text text-white">
      copyright @2022 All rights reserved
     </p>
    </div>
   </div>
   <div class="col-lg-5 col-md-6 col-sm-6">
    <div class="single-footer-widget">
     <h6 style="color: white">Newsletter</h6>
     <p style="color: whitesmoke">Contant Us</p>
     <div>
      <input type="" name="Email" placeholder="Enter Email" class="form-control" />
     </div>
    </div>
   </div>
   <div class="col-lg-2 col-md-6 col-sm-6 social-widget">
    <div class="single-footer-widget">
     <h6 class="text-white">Fllow Us</h6>
     <p class="text-white">Let us be social</p>
     <div class="footer-social d-flex align-items-center">
      <a href="#"><i class="fa-brands fa-facebook"></i></a>
      <a href="#"><i class="fa-brands fa-twitter"></i></a>
      <a href="#"><i class="fa-brands fa-youtube"></i></a>
      <a href="#"><i class="fa-brands fa-discord"></i></a>
     </div>
    </div>
   </div>
  </div>
 </div>
</footer>
<!-- footer end -->
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
 integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>

<!-- 0 jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"
 integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA=="
 crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- cdn files -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"
 integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw=="
 crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- Init Owl Carousel -->
<script>
$('.owl-carousel').owlCarousel({
 loop: true,
 margin: 10,
 nav: true,
 responsive: {
  0: {
   items: 1,
  },
  600: {
   items: 3,
  },
  1000: {
   items: 5,
  },
 },
});
</script>
</body>

</html>